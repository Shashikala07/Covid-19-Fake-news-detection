Based on Twitter's data distribution policy, we only share the Tweet IDs and the annotated labels in this folder.
>The labels used are:
+ 0: Tweets which do not have verifiable information.
+ 1: Tweets which contain verifiable information.
