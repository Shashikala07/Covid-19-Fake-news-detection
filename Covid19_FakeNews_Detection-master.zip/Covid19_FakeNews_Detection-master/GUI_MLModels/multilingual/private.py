# -*- coding: utf-8 -*-
"""
Created on Wed Jun 24 10:22:49 2020

@author: Mohit Bhardwaj
"""

CONSUMER_KEY = ""
CONSUMER_SECRET = ""
OAUTH_TOKEN = ""
OAUTH_TOKEN_SECRET = ""

