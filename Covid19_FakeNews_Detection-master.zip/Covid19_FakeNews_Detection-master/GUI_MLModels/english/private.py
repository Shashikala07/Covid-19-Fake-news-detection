# -*- coding: utf-8 -*-
"""
Created on Wed Jun 24 10:22:49 2020

@author: Mohit Bhardwaj
"""

CONSUMER_KEY = "xxxx"
CONSUMER_SECRET = "xxxx"
OAUTH_TOKEN = "xxxx"
OAUTH_TOKEN_SECRET = "xxxx"

